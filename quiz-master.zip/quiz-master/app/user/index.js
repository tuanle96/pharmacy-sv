'use strict';
var user = require('./user');


exports = module.exports = {
    user: user
}