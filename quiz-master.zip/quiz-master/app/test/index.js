'use strict';
var test = require('./test');


exports = module.exports = {
    test: test
}