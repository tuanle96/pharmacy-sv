'use strict';
var db = require('./db');

exports = module.exports = {
    db: db,
    key: 'quiz'
}