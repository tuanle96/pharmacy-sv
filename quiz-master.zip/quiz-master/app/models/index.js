'use strict';

var test = require('./test');
var user = require('./user');

exports = module.exports = {
    test: test,
    user: user,
}