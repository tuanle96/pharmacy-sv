'use strict';
var authenticate = require('./authenticate');

exports = module.exports = {
    authenticate: authenticate,
}