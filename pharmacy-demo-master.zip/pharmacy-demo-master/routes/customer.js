// 'use strict';

// exports = module.exports = (requireSession, app, customer) => {
//     app.post('/signin', customer.customer.signin);

// };