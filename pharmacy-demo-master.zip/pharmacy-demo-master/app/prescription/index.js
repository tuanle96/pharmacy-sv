var prescription = require('./prescription');

exports = module.exports = {
    prescription: prescription
}