var customer = require('./customer');

exports = module.exports = {
    customer: customer
}