var db = require('./db');

exports = module.exports = {
    db: db,
    secret: 'pharmacy'
}