var drug = require('./drug');

exports = module.exports = {
    drug: drug
}