'use strict';

const districts = ['Chantabuly', 'Sikhottabong', 'Xaysetha', 'Sisattanak', 'Hadxaifong', 'Mayparkngum', 'Naxaithong', 'Sangthong', 'Xaythany'];

exports = module.exports = {
    districts: districts
}